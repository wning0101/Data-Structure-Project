abstract class event {
    protected String name;       //The name of the event
    protected String keyword;   //The key word for this event
    abstract public void add(); //add
    abstract public void adda(String dd, int gg);   //add for data loading
    abstract public void diaplay(); //display
}
